#define MAX_SEQ 1 /* must be 1 for protocol 3 */

#include "protocol.h"
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#define PORT 8080

int socket_connection()
{
    int status, valread, client_fd;
    struct sockaddr_in serv_addr;
    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\n Socket creation error \n");
        return -1;
    }
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    // Convert IPv4 and IPv6 addresses from text to binary
    // form
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)
        <= 0) {
        printf(
            "\nInvalid address/ Address not supported \n");
        return -1;
    }

    if ((status
         = connect(client_fd, (struct sockaddr*)&serv_addr,
                   sizeof(serv_addr)))
        < 0) {
        printf("\nConnection Failed \n");
        return -1;
    }
    return client_fd;
}

void main()
{
    seq_nr frame_expected;
    frame r, s;
    frame_expected = 0;
    FILE *fp=fopen("tmp1.c","wb");
    int socket=socket_connection();
    int offset;
    while(true)
    {
            int no_bytes=recv(socket,&r,sizeof(frame),0); /* go get the newly arrived frame */
            if(no_bytes==-1)
              break;
             float random = (float) rand()/RAND_MAX;
            if(random<0.5)
            {
              printf("Checksum Error\n");
              continue;
            }
            if (r.seq == frame_expected)
            {                              /* this is what we have been waiting for */
                offset+=r.size;
                printf("Received frame:%d\t%d\n",r.seq,offset);
                int count=fwrite(r.info,r.size,1,fp); /* pass the data to the network layer */
                fflush(fp);
                inc(frame_expected);       /* next time expect the other sequence nr */
            }
            else
            {
               printf("Duplicate frame:%d\n",r.seq);
            }
            s.ack = 1 - frame_expected; /* tell which frame is being acked */
            random = (float) rand()/RAND_MAX;
            if(random<0.25)
            {
              usleep(150000);     
              send(socket,&s,sizeof(frame),0);      /* send acknowledgement */
              printf("Delayed Ack sent:%d\n",s.ack);
            }
            else
            {
              send(socket,&s,sizeof(frame),0);      /* send acknowledgement */
              printf("Ack sent:%d\n",s.ack);
            }
    }
    close(socket);
    fflush(fp);
    fflush(stdout);
    fclose(fp);

}

