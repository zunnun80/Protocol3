#define MAX_PKT 1024
typedef enum {false,true} boolean;
typedef unsigned int seq_nr;
typedef struct {unsigned char data[MAX_PKT];} packet;
typedef enum {data, ack, nak} frame_kind;

typedef struct {
frame_kind kind;
seq_nr seq;
seq_nr ack;
int size;
char info[MAX_PKT];
} frame;

#define inc(k) if(k< MAX_SEQ)k=k+1;else k=0;

